import { createServerFn } from "@tanstack/react-start";
import { generateText } from "ai";
import { z } from "zod";
import { createLovableAiGatewayProvider } from "./ai-gateway.server";

const Input = z.object({
  mode: z.enum(["quality", "safety", "recommendation"]),
  treatment: z.string(),
  scenario: z.string(),
  day: z.number(),
  predictedQuality: z.number().nullable().optional(),
  safetyIndex: z.number().nullable().optional(),
  bestTreatment: z.string().nullable().optional(),
  bestIndex: z.number().nullable().optional(),
});

export const getFeature3Insight = createServerFn({ method: "POST" })
  .inputValidator((data: unknown) => Input.parse(data))
  .handler(async ({ data }) => {
    const key = process.env.LOVABLE_API_KEY;
    if (!key) throw new Error("Missing LOVABLE_API_KEY");

    const gateway = createLovableAiGatewayProvider(key);

    const ctxLines: string[] = [
      `Treatment: ${data.treatment}`,
      `Scenario: ${data.scenario}`,
      `Prediction day: ${data.day}`,
    ];
    if (data.predictedQuality != null) ctxLines.push(`Predicted Quality Score: ${data.predictedQuality.toFixed(2)} (0–100)`);
    if (data.safetyIndex != null) ctxLines.push(`Fruit Safety Index: ${data.safetyIndex.toFixed(2)} (0–100)`);
    if (data.bestTreatment) ctxLines.push(`Best treatment by model: ${data.bestTreatment} (index ${data.bestIndex?.toFixed(2) ?? "?"})`);

    const task =
      data.mode === "quality"
        ? "Explain the predicted freshness trajectory and the main biological/physical drivers (morphology, gases, microbial load). Give 1 short actionable tip."
        : data.mode === "safety"
        ? "Interpret the Fruit Safety Index components (quality, morphology, yeasts, total bacteria, lactic bacteria as protective). State whether the produce is safe to eat and why, in 2–3 sentences."
        : "Explain why the recommended treatment is the best option for shelf-life and safety vs the alternatives, and give a short consumer-facing recommendation.";

    const { text } = await generateText({
      model: gateway("google/gemini-3-flash-preview"),
      system:
        "You are BioFreshGuard, an assistant for post-harvest freshness of lettuce. Be concise (max 4 short sentences), data-driven, and friendly. Do not invent numbers — use only those provided.",
      prompt: `${task}\n\nContext:\n${ctxLines.join("\n")}`,
    });

    return { text };
  });
