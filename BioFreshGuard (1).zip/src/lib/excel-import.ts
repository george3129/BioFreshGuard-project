import * as XLSX from "xlsx";
import type { DashboardData, MainRow } from "./biofresh-data";

// Map of canonical metric -> possible header aliases (case-insensitive, trimmed)
const ALIASES: Record<string, string[]> = {
  Day: ["day", "days", "storage_day", "storage day", "time", "time (day)", "time_(day)", "time(day)", "יום"],
  Treatment: ["treatment", "טיפול", "group"],
  morphology: ["morphology", "morphology_rate", "morph", "appearance", "מורפולוגיה"],
  bacteria_total: ["bacteria_total", "total_bacteria", "total bacteria", "tvc", "bacteria", "חיידקים"],
  yeasts: ["yeasts", "yeast", "yeast_mold", "yeasts_molds", "שמרים"],
  lactic_bacteria: ["lactic_bacteria", "lactic", "lab", "lactic acid bacteria"],
  weight_loss: ["weight_loss", "weight loss", "weight loss (%)", "weight_loss_(%)", "wloss", "weightloss", "איבוד משקל"],
  color_delta_E: ["color_delta_e", "delta_e", "deltae", "color", "צבע"],
  texture_force: ["texture_force", "texture", "firmness", "force", "force (%)", "force_(%)", "מרקם"],
  TSS: ["tss", "tss (%)", "tss_(%)", "brix", "soluble_solids"],
  O2: ["o2", "%o2", "%_o2", "oxygen", "o₂"],
  CO2: ["co2", "%co2", "carbon_dioxide", "co₂"],
};

function normKey(s: string) { return s.toString().trim().toLowerCase().replace(/\s+/g, "_"); }

function resolveColumn(headers: string[], canonical: string): string | null {
  const aliases = ALIASES[canonical].map(normKey);
  for (const h of headers) {
    if (aliases.includes(normKey(h))) return h;
  }
  return null;
}

function num(v: any): number | null {
  if (v === null || v === undefined || v === "") return null;
  const n = typeof v === "number" ? v : parseFloat(String(v).replace(/,/g, ""));
  return Number.isFinite(n) ? n : null;
}

function minMax(values: number[]) {
  const min = Math.min(...values), max = Math.max(...values);
  const range = max - min || 1;
  return values.map(v => (v - min) / range);
}

function mean(arr: number[]) { return arr.reduce((a, b) => a + b, 0) / arr.length; }

function corr(x: number[], y: number[]) {
  const mx = mean(x), my = mean(y);
  let num = 0, dx = 0, dy = 0;
  for (let i = 0; i < x.length; i++) {
    num += (x[i] - mx) * (y[i] - my);
    dx += (x[i] - mx) ** 2;
    dy += (y[i] - my) ** 2;
  }
  const d = Math.sqrt(dx * dy);
  return d === 0 ? 0 : num / d;
}

export async function importExcelToDashboard(file: File, base: DashboardData): Promise<DashboardData> {
  const buf = await file.arrayBuffer();
  const wb = XLSX.read(buf, { type: "array" });

  // Collect all rows from all sheets, keyed by (Treatment, Day)
  const byKey = new Map<string, Partial<MainRow>>();

  for (const sheetName of wb.SheetNames) {
    const ws = wb.Sheets[sheetName];
    const rows: Record<string, any>[] = XLSX.utils.sheet_to_json(ws, { defval: null });
    if (!rows.length) continue;
    const headers = Object.keys(rows[0]);
    const dayCol = resolveColumn(headers, "Day");
    const trtCol = resolveColumn(headers, "Treatment");
    if (!dayCol || !trtCol) continue;

    // resolve which metric columns are present in this sheet
    const metricCols: { canonical: keyof MainRow; header: string }[] = [];
    for (const canonical of Object.keys(ALIASES)) {
      if (canonical === "Day" || canonical === "Treatment") continue;
      const h = resolveColumn(headers, canonical);
      if (h) metricCols.push({ canonical: canonical as keyof MainRow, header: h });
    }

    for (const r of rows) {
      const day = num(r[dayCol]);
      const treatment = r[trtCol];
      if (day === null || !treatment) continue;
      const key = `${treatment}__${day}`;
      const existing = byKey.get(key) ?? { Day: day, Treatment: String(treatment) };
      for (const { canonical, header } of metricCols) {
        const v = num(r[header]);
        if (v !== null && (existing as any)[canonical] === undefined) {
          (existing as any)[canonical] = v;
        }
      }
      byKey.set(key, existing);
    }
  }

  const merged = Array.from(byKey.values());
  if (merged.length === 0) throw new Error("לא נמצאו שורות עם עמודות Day ו-Treatment בקובץ.");

  // Fill missing metrics from base by treatment averages (so quality score still computable)
  const required = ["morphology","bacteria_total","yeasts","lactic_bacteria","weight_loss","color_delta_E","texture_force","TSS","O2","CO2"] as const;
  for (const row of merged) {
    for (const k of required) {
      if ((row as any)[k] === undefined || (row as any)[k] === null) {
        const fallback = base.main_df.find(r => r.Treatment === row.Treatment)?.[k];
        (row as any)[k] = fallback ?? 0;
      }
    }
  }

  // log transforms
  for (const r of merged as any[]) {
    r.log_bacteria_total = Math.log1p(r.bacteria_total);
    r.log_yeasts = Math.log1p(r.yeasts);
    r.log_lactic_bacteria = Math.log1p(r.lactic_bacteria);
  }

  // Quality Score (same logic as notebook)
  const pos = ["morphology", "texture_force", "O2", "log_lactic_bacteria"] as const;
  const neg = ["CO2", "weight_loss", "color_delta_E", "log_bacteria_total", "log_yeasts"] as const;
  const scaledPos = pos.map(k => minMax(merged.map((r: any) => r[k])));
  const scaledNeg = neg.map(k => minMax(merged.map((r: any) => r[k])));
  merged.forEach((r: any, i) => {
    const p = scaledPos.reduce((s, col) => s + col[i], 0) / pos.length;
    const n = scaledNeg.reduce((s, col) => s + col[i], 0) / neg.length;
    r.Quality_Score = Math.max(0, Math.min(100, 100 * (0.65 * p + 0.35 * (1 - n))));
    // keep PC1/PC2 from base if available, else 0
    const baseRow = base.main_df.find(b => b.Treatment === r.Treatment && b.Day === r.Day);
    r.PC1 = baseRow?.PC1 ?? 0;
    r.PC2 = baseRow?.PC2 ?? 0;
  });

  merged.sort((a: any, b: any) => a.Treatment.localeCompare(b.Treatment) || a.Day - b.Day);
  const main_df = merged as MainRow[];

  // Treatments + days
  const treatments = Array.from(new Set(main_df.map(r => r.Treatment)));
  const days = Array.from(new Set(main_df.map(r => r.Day))).sort((a, b) => a - b);

  // Treatment summary
  const treatment_summary = treatments.map(t => {
    const rows = main_df.filter(r => r.Treatment === t);
    const last = rows[rows.length - 1];
    return {
      Treatment: t,
      Mean_Quality: mean(rows.map(r => r.Quality_Score)),
      Day_14_Quality: last.Quality_Score,
      Mean_Morphology: mean(rows.map(r => r.morphology)),
      Mean_CO2: mean(rows.map(r => r.CO2)),
      Mean_O2: mean(rows.map(r => r.O2)),
      Mean_Bacteria: mean(rows.map(r => r.bacteria_total)),
    };
  }).sort((a, b) => (b.Mean_Quality as number) - (a.Mean_Quality as number));
  const best_treatment = String(treatment_summary[0].Treatment);

  // Correlation matrix
  const corrFeatures = ["Day","morphology","CO2","O2","TSS","texture_force","weight_loss","color_delta_E","log_bacteria_total","log_yeasts","log_lactic_bacteria","Quality_Score","PC1","PC2"];
  const matrix = corrFeatures.map(a =>
    corrFeatures.map(b => +corr(main_df.map((r: any) => r[a]), main_df.map((r: any) => r[b])).toFixed(3))
  );

  // PCA points reuse base PCA if treatments/days align, otherwise drop unmatched
  const pcaPoints = main_df.map(r => ({
    PC1: r.PC1, PC2: r.PC2, Day: r.Day, Treatment: r.Treatment, Quality_Score: r.Quality_Score,
  }));

  return {
    ...base,
    treatments,
    days,
    main_df,
    treatment_summary,
    best_treatment,
    correlation: { features: corrFeatures, matrix },
    pca: { ...base.pca, points: pcaPoints },
  };
}
