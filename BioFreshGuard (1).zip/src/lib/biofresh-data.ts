export type Treatment = string;
export type Day = number;

export interface MainRow {
  Day: number; Treatment: string;
  morphology: number; bacteria_total: number; yeasts: number; lactic_bacteria: number;
  weight_loss: number; color_delta_E: number; texture_force: number;
  TSS: number; O2: number; CO2: number;
  log_bacteria_total: number; log_yeasts: number; log_lactic_bacteria: number;
  Quality_Score: number; PC1: number; PC2: number;
}

export interface DashboardData {
  treatments: string[];
  days: number[];
  main_df: MainRow[];
  treatment_summary: Array<Record<string, string | number>>;
  best_treatment: string;
  pca: {
    features: string[];
    explained_variance: number[];
    loadings: { feature: string; PC1: number; PC2: number }[];
    points: { PC1: number; PC2: number; Day: number; Treatment: string; Quality_Score: number }[];
  };
  correlation: { features: string[]; matrix: number[][] };
  anova: { quality: { F: number; p: number }; morphology: { F: number; p: number } };
  linear_regression: {
    r2: number; mae: number;
    coefficients: { feature: string; coef: number }[];
    actual_vs_pred: { actual: number; predicted: number }[];
  };
  random_forest: {
    r2: number; mae: number;
    feature_importance: { feature: string; importance: number }[];
  };
  scenarios: string[];
  simulation_results: Record<string, {
    history: number[][][];
    progression: number[];
    final_grid: number[][];
    initial_pct: number; final_pct: number;
  }>;
}

let cache: DashboardData | null = null;
export async function loadData(): Promise<DashboardData> {
  if (cache) return cache;
  const res = await fetch("/data.json");
  cache = await res.json();
  return cache!;
}

// Treatment color palette — consistent across all charts
// Treatments come from the real BioFreshGuard Excel database
export const TREATMENT_COLORS: Record<string, string> = {
  "control": "#64748b",
  "CMC-3-methyl": "#34d399",
  "CMC-3-methyl+A": "#f59e0b",
  "CMC-3-methyl+B": "#a78bfa",
  "CMC-3-methyl+C": "#86efac",
};
export function colorFor(t: string, fallback = "#2563eb") {
  return TREATMENT_COLORS[t] ?? fallback;
}

export function qualityStatus(value: number): { label: string; color: string } {
  if (value >= 70) return { label: "Fresh / Good", color: "#16a34a" };
  if (value >= 40) return { label: "Warning", color: "#f59e0b" };
  return { label: "High Spoilage Risk", color: "#dc2626" };
}
