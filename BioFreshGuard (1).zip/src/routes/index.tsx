import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { useServerFn } from "@tanstack/react-start";
import { loadData, type DashboardData, colorFor, qualityStatus, TREATMENT_COLORS } from "@/lib/biofresh-data";
import { Plot } from "@/components/Plot";
import { CAAnimation } from "@/components/CAAnimation";
import { DatasetUploader } from "@/components/DatasetUploader";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Leaf, FlaskConical, BarChart3, ScatterChart, Activity, Beaker, Wind, Bug, Map as MapIcon, Boxes, Sparkles, ArrowLeft, TrendingDown, ShieldCheck, Award, Loader2 } from "lucide-react";
import lettuceDecayVideo from "@/assets/lettuce-decay.mp4.asset.json";
import { getFeature3Insight } from "@/lib/feature3-insight.functions";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "BioFreshGuard — Ecological Freshness Intelligence" },
      { name: "description", content: "Data-driven dashboard for post-harvest freshness and spoilage dynamics of lettuce under biological treatments." },
    ],
  }),
  component: Dashboard,
});

type View = "home" | "f1" | "f2" | "f3";

function Dashboard() {
  const [data, setData] = useState<DashboardData | null>(null);
  const [view, setView] = useState<View>("home");

  useEffect(() => { loadData().then(setData); }, []);

  if (!data) return (
    <div className="min-h-screen grid place-items-center text-muted-foreground">
      <div className="flex items-center gap-3">
        <Leaf className="size-5 animate-pulse text-primary" />
        <span>Loading BioFreshGuard data…</span>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen">
      <Header view={view} onHome={() => setView("home")} />
      <main className="mx-auto max-w-7xl px-6 pb-20">
        {view === "home" && <Home data={data} onGo={setView} onLoaded={setData} />}
        {view === "f1" && <Feature1 data={data} />}
        {view === "f2" && <Feature2 data={data} />}
        {view === "f3" && <Feature3 data={data} />}
      </main>
      <footer className="mx-auto max-w-7xl px-6 py-8 text-xs text-muted-foreground border-t border-border">
        BioFreshGuard · Ecological Freshness Intelligence System · {data.main_df.length} samples · {data.treatments.length} treatments
      </footer>
    </div>
  );
}

function Header({ view, onHome }: { view: View; onHome: () => void }) {
  return (
    <header className="sticky top-0 z-20 backdrop-blur-md bg-background/80 border-b border-border">
      <div className="mx-auto max-w-7xl px-6 h-16 flex items-center justify-between">
        <button onClick={onHome} className="flex items-center gap-2.5 group">
          <div className="size-9 rounded-xl hero-grad grid place-items-center shadow-sm">
            <Leaf className="size-5 text-white" />
          </div>
          <div className="text-left">
            <div className="font-display font-semibold tracking-tight">BioFreshGuard</div>
            <div className="text-[10px] uppercase tracking-widest text-muted-foreground -mt-0.5">Freshness Intelligence</div>
          </div>
        </button>
        {view !== "home" && (
          <Button variant="ghost" size="sm" onClick={onHome} className="gap-2">
            <ArrowLeft className="size-4" /> Home
          </Button>
        )}
      </div>
    </header>
  );
}

/* ============================================================ HOME */
function Home({ data, onGo, onLoaded }: { data: DashboardData; onGo: (v: View) => void; onLoaded: (d: DashboardData) => void }) {
  const best = data.best_treatment;
  return (
    <div className="pt-8 space-y-8">
      <section className="card-soft overflow-hidden relative border-0">
        <div className="grid lg:grid-cols-[340px_1fr] min-h-[352px]">
          {/* LEFT: title + buttons */}
          <div className="relative z-10 p-6 lg:p-8 flex flex-col gap-5 bg-[var(--card)]/85 backdrop-blur-sm">
            <div>
              <h1 className="text-4xl lg:text-5xl font-display font-semibold leading-[1.05] tracking-tight">
                BioFreshGuard
              </h1>
              <p className="mt-3 text-sm text-muted-foreground">
                Freshness Intelligence System
              </p>
            </div>
            <div>
              <DatasetUploader data={data} onLoaded={onLoaded} />
            </div>
            <div className="flex flex-col gap-2.5">
              <Button size="lg" onClick={() => onGo("f1")} className="justify-start gap-2 w-full">
                <BarChart3 className="size-4" /> Main Ecological Visualization
              </Button>
              <Button size="lg" onClick={() => onGo("f2")} className="justify-start gap-2 w-full">
                <MapIcon className="size-4" /> Treatment + Scenario Dashboard
              </Button>
              <Button size="lg" onClick={() => onGo("f3")} className="justify-start gap-2 w-full">
                <Activity className="size-4" /> Prediction + Recommendation
              </Button>
            </div>
          </div>
          {/* RIGHT: decay video */}
          <div className="relative min-h-[280px] lg:min-h-full overflow-hidden">
            <video
              className="absolute inset-0 w-full h-full object-cover"
              src={lettuceDecayVideo.url}
              autoPlay muted loop playsInline
            />
            <div className="absolute inset-0 bg-gradient-to-r from-[var(--card)] via-transparent to-transparent lg:to-[var(--card)]/20" />
            <div className="absolute bottom-4 right-4 text-[10px] uppercase tracking-widest text-white/70 bg-black/40 backdrop-blur-sm px-2.5 py-1 rounded">
              Lettuce decay · time-lapse
            </div>
          </div>
        </div>
      </section>


      <section className="grid md:grid-cols-3 gap-5">
        <FeatureCard
          title="Feature 1"
          subtitle="Ecological overview"
          desc="Quality score, morphology, PCA biplot and the full correlation matrix across all criteria."
          icon={<BarChart3 className="size-5" />}
          onClick={() => onGo("f1")}
        />
        <FeatureCard
          title="Feature 2"
          subtitle="Treatment × Scenario"
          desc="Pick a treatment, scenario and microbe to drive a Game-of-Life spoilage simulation plus 5 sub-graphs."
          icon={<MapIcon className="size-5" />}
          onClick={() => onGo("f2")}
        />
        <FeatureCard
          title="Feature 3"
          subtitle="Statistical models"
          desc="ANOVA, linear regression on morphology and a Random Forest predicting Quality Score."
          icon={<Activity className="size-5" />}
          onClick={() => onGo("f3")}
        />
      </section>
    </div>
  );
}

function Stat({ label, value, accent, icon }: { label: string; value: string; accent: "leaf" | "ocean" | "amber"; icon: React.ReactNode }) {
  const color = accent === "leaf" ? "var(--leaf)" : accent === "ocean" ? "var(--ocean)" : "var(--amber)";
  return (
    <Card className="card-soft p-5 border-0">
      <div className="flex items-center gap-2 text-xs uppercase tracking-widest text-muted-foreground">
        <span className="size-6 rounded-md grid place-items-center text-white" style={{ background: color }}>{icon}</span>
        {label}
      </div>
      <div className="mt-3 text-2xl font-display font-semibold">{value}</div>
    </Card>
  );
}

function FeatureCard({ title, subtitle, desc, icon, onClick }: { title: string; subtitle: string; desc: string; icon: React.ReactNode; onClick: () => void }) {
  return (
    <button onClick={onClick} className="card-soft p-5 text-left hover:-translate-y-0.5 transition-transform hover:shadow-[var(--shadow-elevated)] border-0">
      <div className="flex items-center gap-3">
        <div className="size-10 rounded-xl grid place-items-center text-primary-foreground hero-grad">{icon}</div>
        <div>
          <div className="text-xs uppercase tracking-widest text-muted-foreground">{title}</div>
          <div className="font-display font-semibold">{subtitle}</div>
        </div>
      </div>
      <p className="mt-4 text-sm text-muted-foreground leading-relaxed">{desc}</p>
    </button>
  );
}

/* ============================================================ FEATURE 1 */
function Feature1({ data }: { data: DashboardData }) {
  type G = "quality" | "morphology" | "pca" | "corr";
  const [g, setG] = useState<G>("quality");

  const items: { id: G; label: string; desc: string; icon: React.ReactNode; color: string }[] = [
    { id: "quality",    label: "Quality Score Over Time", desc: "Overall lettuce quality across storage days and treatments.", icon: <BarChart3 className="size-4" />, color: "var(--leaf)" },
    { id: "morphology", label: "Morphology Over Time",    desc: "Visual appearance deterioration as a spoilage proxy.",        icon: <Leaf className="size-4" />,      color: "var(--mint)" },
    { id: "pca",        label: "PCA Biplot",              desc: "Multivariate separation with criteria loadings.",             icon: <ScatterChart className="size-4" />, color: "var(--ocean)" },
    { id: "corr",       label: "Correlation Matrix",      desc: "Relationships between quality, gases, microbes and physics.", icon: <Boxes className="size-4" />,     color: "var(--plum)" },
  ];

  return (
    <div className="pt-8 space-y-6">
      <SectionHero title="Feature 1" subtitle="Ecological Overview" desc="Four charts that summarize the freshness-spoilage system across all treatments." />
      <div className="grid lg:grid-cols-[320px_1fr] gap-5">
        <div className="space-y-3">
          {items.map(it => (
            <Button
              key={it.id}
              onClick={() => setG(it.id)}
              className={`w-full justify-start h-auto text-left py-3 px-4 gap-2 ${g === it.id ? "" : "opacity-60 hover:opacity-100"}`}
            >
              {it.icon}
              <div className="flex flex-col items-start">
                <span className="font-medium text-sm">{it.label}</span>
                <span className="text-xs opacity-80 leading-relaxed">{it.desc}</span>
              </div>
            </Button>
          ))}
        </div>
        <Card className="card-soft p-5 border-0 min-h-[345px]">
          {g === "quality"    && <QualityChart data={data} />}
          {g === "morphology" && <MorphologyChart data={data} />}
          {g === "pca"        && <PCABiplot data={data} />}
          {g === "corr"       && <CorrelationChart data={data} />}
        </Card>
      </div>

      <Card className="card-soft p-5 border-0">
        <h3 className="font-display font-semibold mb-3">Treatment Summary</h3>
        <div className="overflow-x-auto">
          <table className="w-full text-sm">
            <thead className="text-xs uppercase tracking-wider text-muted-foreground border-b border-border">
              <tr>{Object.keys(data.treatment_summary[0]).map(k => (
                <th key={k} className="py-2 pr-4 text-left font-medium">{k.replace(/_/g, " ")}</th>
              ))}</tr>
            </thead>
            <tbody>
              {data.treatment_summary.map((row, i) => (
                <tr key={i} className="border-b border-border/60 last:border-0">
                  {Object.entries(row).map(([k, v]) => (
                    <td key={k} className="py-2.5 pr-4">
                      {k === "Treatment"
                        ? <span className="inline-flex items-center gap-2"><span className="size-2.5 rounded-full" style={{ background: colorFor(String(v)) }} />{String(v)}</span>
                        : v == null ? "—" : typeof v === "number" ? v.toFixed(2) : String(v)}
                    </td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        <div className="mt-3 text-xs text-muted-foreground">
          Best treatment by mean Quality Score: <span className="font-semibold text-foreground">{data.best_treatment}</span>
        </div>
      </Card>
    </div>
  );
}

function QualityChart({ data }: { data: DashboardData }) {
  const traces = data.treatments.map(t => {
    const rows = data.main_df.filter(r => r.Treatment === t);
    return {
      x: rows.map(r => r.Day),
      y: rows.map(r => r.Quality_Score),
      type: "scatter", mode: "lines+markers",
      name: t, line: { width: 3, color: colorFor(t) }, marker: { size: 9 },
    };
  });
  return <Plot data={traces} layout={{
    title: "BioFreshGuard — Quality Score Over Time",
    xaxis: { title: { text: "Storage Day" } },
    yaxis: { title: { text: "Quality Score" }, range: [0, 105] },
    legend: { title: { text: "Treatment" } },
  }} style={{ height: 330 }} />;
}

function MorphologyChart({ data }: { data: DashboardData }) {
  const traces = data.treatments.map(t => {
    const rows = data.main_df.filter(r => r.Treatment === t);
    return {
      x: rows.map(r => r.Day), y: rows.map(r => r.morphology),
      type: "scatter", mode: "lines+markers", name: t,
      line: { width: 3, color: colorFor(t) }, marker: { size: 9 },
    };
  });
  return <Plot data={traces} layout={{
    title: "Morphology Over Time",
    xaxis: { title: { text: "Storage Day" } },
    yaxis: { title: { text: "Morphology" } },
  }} style={{ height: 330 }} />;
}

function PCABiplot({ data }: { data: DashboardData }) {
  const scale = 3;
  const traces: any[] = data.treatments.map(t => {
    const pts = data.pca.points.filter(p => p.Treatment === t);
    return {
      x: pts.map(p => p.PC1), y: pts.map(p => p.PC2), text: pts.map(p => `Day ${p.Day}`),
      mode: "markers+text", type: "scatter", name: t, textposition: "top center",
      marker: { size: pts.map(p => 8 + p.Quality_Score / 6), color: colorFor(t), line: { color: "#fff", width: 1 } },
    };
  });
  const shapes = data.pca.loadings.map(l => ({
    type: "line", x0: 0, y0: 0, x1: l.PC1 * scale, y1: l.PC2 * scale,
    line: { color: "#94a3b8", width: 1 },
  }));
  const annotations = data.pca.loadings.map(l => ({
    x: l.PC1 * scale, y: l.PC2 * scale, text: l.feature,
    showarrow: false, font: { size: 10, color: "#475569" },
  }));
  return <Plot data={traces} layout={{
    title: `PCA Biplot — PC1 (${(data.pca.explained_variance[0] * 100).toFixed(1)}%) vs PC2 (${(data.pca.explained_variance[1] * 100).toFixed(1)}%)`,
    xaxis: { title: { text: "PC1" }, zeroline: true }, yaxis: { title: { text: "PC2" }, zeroline: true },
    shapes, annotations,
  }} style={{ height: 360 }} />;
}

function CorrelationChart({ data }: { data: DashboardData }) {
  return <Plot data={[{
    z: data.correlation.matrix, x: data.correlation.features, y: data.correlation.features,
    type: "heatmap", colorscale: "RdBu", reversescale: true, zmin: -1, zmax: 1,
    text: data.correlation.matrix.map(r => r.map(v => v.toFixed(2))), texttemplate: "%{text}",
    textfont: { size: 9 }, hoverongaps: false,
  }]} layout={{
    title: "Correlation Matrix — BioFreshGuard Criteria",
    margin: { l: 130, b: 130, t: 56, r: 24 },
    xaxis: { tickangle: -45 },
  }} style={{ height: 420 }} />;
}

/* ============================================================ FEATURE 2 */
function Feature2({ data }: { data: DashboardData }) {
  const microbeOptions = ["bacteria_total", "yeasts", "lactic_bacteria"];
  const [treatment, setTreatment] = useState(data.treatments[0]);
  const [scenario, setScenario] = useState(data.scenarios[0]);
  const [microbe, setMicrobe] = useState(microbeOptions[0]);
  const [ran, setRan] = useState(false);
  const [subGraph, setSubGraph] = useState<"sim" | "bact" | "gas" | "main" | "pca" | "scen">("sim");

  const tempDf = useMemo(
    () => data.main_df.filter(r => r.Treatment === treatment).sort((a, b) => a.Day - b.Day),
    [data, treatment]
  );
  const startQ = tempDf[0]?.Quality_Score ?? 0;
  const finalQ = tempDf[tempDf.length - 1]?.Quality_Score ?? 0;
  const status = qualityStatus(finalQ);

  const sim = data.simulation_results[scenario];

  return (
    <div className="pt-8 space-y-6">
      <SectionHero title="Feature 2" subtitle="Treatment & Scenario Dashboard"
        desc="Pick a treatment, a scenario and a microbial variable, then explore the graphs below." />

      {/* Selection — same style as Feature 3 */}
      <Card className="card-soft p-0 border-0 overflow-hidden max-w-xl">
        <div className="bg-muted/60 px-4 py-2.5 text-sm font-display font-semibold">Feature 2 Selection</div>
        <div className="p-4 space-y-3">
          <SelectRow label="Treatment" value={treatment} onChange={setTreatment} options={data.treatments} />
          <SelectRow label="Scenario" value={scenario} onChange={setScenario} options={data.scenarios} />
          <SelectRow label="Microbial" value={microbe} onChange={setMicrobe} options={microbeOptions} />
          <Button onClick={() => { setRan(true); setSubGraph("sim"); }} className="w-full mt-2" size="lg">
            Run Feature 2
          </Button>
        </div>
      </Card>

      {ran && (
        <>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            <Kpi label="Initial Quality" value={startQ.toFixed(2)} color="var(--leaf)" />
            <Kpi label="Final Quality"   value={finalQ.toFixed(2)} color="var(--ocean)" />
            <Kpi label="Quality Change"  value={(finalQ - startQ).toFixed(2)} color="var(--amber)" />
            <Kpi label="Status"          value={status.label} color={status.color} />
          </div>

          <div className="grid lg:grid-cols-[260px_1fr] gap-5">
            <div className="space-y-2">
              {([
                ["sim",  "Spatial Simulation",            <MapIcon className="size-4" />,    "var(--leaf)"],
                ["bact", "Selected Bacterial",           <Bug className="size-4" />,        "var(--coral)"],
                ["gas",  "CO₂ and O₂",                   <Wind className="size-4" />,       "var(--ocean)"],
                ["main", "Main Criteria",                <Beaker className="size-4" />,     "var(--leaf)"],
                ["pca",  "PCA Map",                      <ScatterChart className="size-4" />, "var(--plum)"],
                ["scen", "Scenario Comparison",          <MapIcon className="size-4" />,    "var(--amber)"],
              ] as const).map(([id, label, icon, color]) => {
                const active = subGraph === id;
                return (
                  <button key={id} onClick={() => setSubGraph(id)}
                    className={`w-full text-left rounded-xl p-3 transition border-l-4 ${active ? "shadow-md" : "opacity-60 hover:opacity-100"}`}
                    style={{
                      borderLeftColor: color as string,
                      background: active ? (color as string) : "hsl(var(--card))",
                      color: active ? "#fff" : "inherit",
                    }}>
                    <div className="flex items-center gap-2 text-sm font-medium">{icon}{label}</div>
                  </button>
                );
              })}
            </div>
            <Card className="card-soft p-5 border-0 min-h-[420px]">
              {subGraph === "sim"  && (
                <div>
                  <h3 className="font-display font-semibold mb-1">Spatial Spoilage Simulation</h3>
                  <p className="text-xs text-muted-foreground mb-4">
                    Cellular-automata spread (fresh → spoiled) modulated by the {scenario.toLowerCase()} scenario parameters.
                  </p>
                  <CAAnimation history={sim.history} fps={3} />
                  <div className="mt-3 text-xs text-muted-foreground grid grid-cols-2 gap-2 max-w-md mx-auto">
                    <div><b>Treatment:</b> {treatment}</div>
                    <div><b>Scenario:</b> {scenario}</div>
                    <div><b>Microbe:</b> {microbe}</div>
                    <div><b>Final spoilage:</b> {sim.final_pct.toFixed(1)}%</div>
                  </div>
                </div>
              )}
              {subGraph === "bact" && <BacterialChart df={tempDf} microbe={microbe} treatment={treatment} />}
              {subGraph === "gas"  && <GasChart df={tempDf} treatment={treatment} />}
              {subGraph === "main" && <MainCriteriaChart df={tempDf} treatment={treatment} />}
              {subGraph === "pca"  && <PCAHighlight data={data} treatment={treatment} />}
              {subGraph === "scen" && <ScenarioComparison data={data} />}
            </Card>
          </div>
        </>
      )}
    </div>
  );
}

function ChipGroup({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: readonly string[] | string[] }) {
  const palette = ["#16a34a", "#0ea5e9", "#f59e0b", "#db2777", "#7c3aed", "#dc2626", "#0891b2", "#65a30d"];
  return (
    <div>
      <div className="text-xs uppercase tracking-widest text-muted-foreground mb-2">{label}</div>
      <div className="flex flex-wrap gap-2">
        {options.map((opt, i) => {
          const active = opt === value;
          const color = palette[i % palette.length];
          return (
            <button key={opt} onClick={() => onChange(opt)}
              className="px-3 py-1.5 rounded-full text-xs font-medium transition border"
              style={{
                background: active ? color : "transparent",
                color: active ? "#fff" : color,
                borderColor: color,
                boxShadow: active ? `0 4px 12px -4px ${color}` : "none",
              }}>
              {opt}
            </button>
          );
        })}
      </div>
    </div>
  );
}


function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <span className="text-xs uppercase tracking-widest text-muted-foreground">{label}</span>
      <div className="mt-1.5">{children}</div>
    </label>
  );
}

function Kpi({ label, value, color }: { label: string; value: string; color: string }) {
  return (
    <Card className="card-soft p-5 border-0 border-l-4" style={{ borderLeftColor: color }}>
      <div className="text-xs uppercase tracking-widest text-muted-foreground">{label}</div>
      <div className="mt-2 font-display font-semibold text-2xl">{value}</div>
    </Card>
  );
}

function Empty({ msg }: { msg: string }) {
  return <div className="h-full grid place-items-center text-muted-foreground text-sm">{msg}</div>;
}

function BacterialChart({ df, microbe, treatment }: { df: any[]; microbe: string; treatment: string }) {
  const ys = df.map(r => Number(r[microbe] ?? 0));
  const logYs = df.map(r => {
    const v = Number(r[`log_${microbe}`]);
    if (Number.isFinite(v) && v > 0) return v;
    const raw = Number(r[microbe] ?? 0);
    return raw > 0 ? Math.log10(raw) : 0;
  });
  return <Plot data={[
    {
      x: df.map(r => r.Day), y: logYs,
      name: `log10(${microbe})`,
      type: "scatter", mode: "lines+markers",
      line: { width: 3, color: colorFor(treatment) }, marker: { size: 11 },
      hovertemplate: "Day %{x}<br>log10: %{y:.2f}<br>raw: %{customdata}<extra></extra>",
      customdata: ys,
    },
  ]} layout={{
    title: `${microbe} — ${treatment}`,
    xaxis: { title: { text: "Storage Day" } },
    yaxis: { title: { text: `log10(${microbe})` } },
  }} style={{ height: 420 }} />;
}

function GasChart({ df, treatment }: { df: any[]; treatment: string }) {
  return <Plot data={[
    { x: df.map(r => r.Day), y: df.map(r => r.O2),  name: "O₂",  type: "scatter", mode: "lines+markers", line: { width: 3, color: "#0ea5e9" }, marker: { size: 10 } },
    { x: df.map(r => r.Day), y: df.map(r => r.CO2), name: "CO₂", type: "scatter", mode: "lines+markers", line: { width: 3, color: "#dc2626" }, marker: { size: 10 } },
  ]} layout={{
    title: `Gas Dynamics — ${treatment}`,
    xaxis: { title: { text: "Storage Day" } },
    yaxis: { title: { text: "Concentration (%)" } },
  }} style={{ height: 420 }} />;
}

function MainCriteriaChart({ df, treatment }: { df: any[]; treatment: string }) {
  const series = [
    { key: "morphology",    name: "Morphology",   color: "#16a34a" },
    { key: "texture_force", name: "Texture",      color: "#7c3aed" },
    { key: "weight_loss",   name: "Weight loss",  color: "#f59e0b" },
    { key: "color_delta_E", name: "Color ΔE",     color: "#dc2626" },
    { key: "TSS",           name: "TSS",          color: "#0ea5e9" },
  ];
  return <Plot data={series.map(s => ({
    x: df.map(r => r.Day), y: df.map(r => r[s.key]),
    name: s.name, type: "scatter", mode: "lines+markers",
    line: { color: s.color, width: 2.5 }, marker: { size: 8 },
  }))} layout={{
    title: `Main Criteria Over Time — ${treatment}`,
    xaxis: { title: { text: "Storage Day" } },
    yaxis: { title: { text: "Value" } },
  }} style={{ height: 420 }} />;
}

function PCAHighlight({ data, treatment }: { data: DashboardData; treatment: string }) {
  const traces = data.treatments.map(t => {
    const pts = data.pca.points.filter(p => p.Treatment === t);
    return {
      x: pts.map(p => p.PC1), y: pts.map(p => p.PC2), name: t,
      mode: "markers", type: "scatter",
      marker: {
        size: pts.map(p => 8 + p.Quality_Score / 6),
        color: colorFor(t),
        opacity: t === treatment ? 1 : 0.25,
        line: { color: "#fff", width: 1 },
      },
    };
  });
  return <Plot data={traces} layout={{
    title: `PCA Map — Highlighting ${treatment}`,
    xaxis: { title: { text: "PC1" } }, yaxis: { title: { text: "PC2" } },
  }} style={{ height: 440 }} />;
}

function ScenarioComparison({ data }: { data: DashboardData }) {
  const colors: Record<string, string> = { Baseline: "#0ea5e9", Stress: "#dc2626", Recovery: "#16a34a" };
  return <Plot data={data.scenarios.map(s => ({
    x: data.simulation_results[s].progression.map((_, i) => i),
    y: data.simulation_results[s].progression,
    name: s, type: "scatter", mode: "lines+markers",
    line: { width: 3, color: colors[s] }, marker: { size: 9 },
  }))} layout={{
    title: "Scenario Comparison — Spatial Spoilage Progression",
    xaxis: { title: { text: "Simulation Step" } },
    yaxis: { title: { text: "Spoiled Area (%)" } },
  }} style={{ height: 440 }} />;
}

/* ============================================================ FEATURE 3 */
type F3Mode = "quality" | "safety" | "recommendation";

const SCENARIO_K_MULT: Record<string, number> = { Baseline: 1.0, Stress: 1.6, Recovery: 0.55 };
const FUTURE_DAYS = [14, 18, 21, 25, 28];

function fitDecay(xs: number[], ys: number[]): { Q0: number; k: number } {
  // log-linear regression on ln(max(y,1))
  const yL = ys.map(y => Math.log(Math.max(y, 1)));
  const n = xs.length;
  const sx = xs.reduce((a, b) => a + b, 0);
  const sy = yL.reduce((a, b) => a + b, 0);
  const sxx = xs.reduce((a, b) => a + b * b, 0);
  const sxy = xs.reduce((a, b, i) => a + b * yL[i], 0);
  const denom = n * sxx - sx * sx || 1;
  const slope = (n * sxy - sx * sy) / denom;
  const intercept = (sy - slope * sx) / n;
  return { Q0: Math.exp(intercept), k: Math.max(0, -slope) };
}

function predictQuality(data: DashboardData, treatment: string, scenario: string, day: number) {
  const rows = data.main_df.filter(r => r.Treatment === treatment).sort((a, b) => a.Day - b.Day);
  const { Q0, k } = fitDecay(rows.map(r => r.Day), rows.map(r => r.Quality_Score));
  const kAdj = k * (SCENARIO_K_MULT[scenario] ?? 1);
  return { rows, predicted: Math.max(0, Math.min(100, Q0 * Math.exp(-kAdj * day))), Q0, k: kAdj };
}

function safetyComponents(data: DashboardData, treatment: string, scenario: string, day: number) {
  const { rows, predicted } = predictQuality(data, treatment, scenario, day);
  const last = rows[rows.length - 1];
  const morphologyPct = Math.max(0, Math.min(100, (last?.morphology ?? 0) / 5 * 100 * Math.exp(-0.04 * Math.max(0, day - 14))));
  const yeastsSafety = Math.max(0, Math.min(100, 100 - (last?.log_yeasts ?? 0) * 12));
  const bactSafety = Math.max(0, Math.min(100, 100 - (last?.log_bacteria_total ?? 0) * 10));
  const lacticProtect = Math.max(0, Math.min(100, (last?.log_lactic_bacteria ?? 0) * 14));
  const components = [
    { name: "Quality Score",       value: predicted,      color: "#16a34a" },
    { name: "Morphology",          value: morphologyPct,  color: "#0ea5e9" },
    { name: "Lactic Protection",   value: lacticProtect,  color: "#7c3aed" },
    { name: "Yeasts Safety",       value: yeastsSafety,   color: "#f59e0b" },
    { name: "Total Bacteria Safety", value: bactSafety,   color: "#dc2626" },
  ];
  const index = components.reduce((a, c) => a + c.value, 0) / components.length;
  return { components, index, predicted };
}

function eatingRec(idx: number) {
  if (idx >= 70) return { label: "Recommended to Eat", color: "#16a34a" };
  if (idx >= 45) return { label: "Eat Soon / Check Before Eating", color: "#f59e0b" };
  return { label: "Not Recommended to Eat", color: "#dc2626" };
}

function Feature3({ data }: { data: DashboardData }) {
  const [treatment, setTreatment] = useState(data.treatments[0]);
  const [scenario, setScenario]   = useState(data.scenarios[0]);
  const [day, setDay]             = useState<number>(21);
  const [mode, setMode]           = useState<F3Mode | null>(null);

  return (
    <div className="pt-8 space-y-6">
      <SectionHero title="Feature 3" subtitle="Prediction & Recommendation"
        desc="Pick a treatment, scenario and prediction day, then choose what to compute — future Quality, Fruit Safety Index, or a Smart Recommendation across all treatments." />

      <div className="grid lg:grid-cols-[320px_1fr] gap-5">
        {/* ============ LEFT — Selection + buttons ============ */}
        <div className="space-y-4">
          <Card className="card-soft p-0 border-0 overflow-hidden">
            <div className="bg-muted/60 px-4 py-2.5 text-sm font-display font-semibold">Feature 3 Selection</div>
            <div className="p-4 space-y-3">
              <SelectRow label="Treatment" value={treatment} onChange={setTreatment} options={data.treatments} />
              <SelectRow label="Scenario"  value={scenario}  onChange={setScenario}  options={data.scenarios} />
              <SelectRow label="Day" value={String(day)} onChange={v => setDay(Number(v))} options={FUTURE_DAYS.map(String)} />
            </div>
          </Card>

          <PredictionBtn
            active={mode === "quality"} onClick={() => setMode("quality")}
            color="#16a34a" icon={<TrendingDown className="size-4" />}
            title="Quality Prediction"
            desc="Predicts future Quality Score based on the observed trend." />
          <PredictionBtn
            active={mode === "safety"} onClick={() => setMode("safety")}
            color="#0ea5e9" icon={<ShieldCheck className="size-4" />}
            title="Fruit Safety Index"
            desc="Evaluates if the fruit is recommended to eat using quality, morphology and microbial role." />
          <PredictionBtn
            active={mode === "recommendation"} onClick={() => setMode("recommendation")}
            color="#7c3aed" icon={<Award className="size-4" />}
            title="Smart Recommendation"
            desc="Compares treatments and recommends the best option using Quality and Fruit Safety Index." />
        </div>

        {/* ============ RIGHT — Result panel ============ */}
        <div>
          {mode === null && (
            <Card className="card-soft p-8 border-0 border-l-4" style={{ borderLeftColor: "var(--leaf)" }}>
              <h3 className="font-display font-semibold text-lg">Feature 3 Prediction Preview</h3>
              <p className="mt-2 text-sm text-muted-foreground">Choose one of the prediction buttons on the left. The selected result will appear here.</p>
            </Card>
          )}
          {mode === "quality"        && <QualityPredictionPanel        data={data} treatment={treatment} scenario={scenario} day={day} />}
          {mode === "safety"         && <FruitSafetyPanel              data={data} treatment={treatment} scenario={scenario} day={day} />}
          {mode === "recommendation" && <SmartRecommendationPanel      data={data} scenario={scenario} day={day} />}
        </div>
      </div>
    </div>
  );
}

function SelectRow({ label, value, onChange, options }: { label: string; value: string; onChange: (v: string) => void; options: readonly string[] | string[] }) {
  return (
    <label className="grid grid-cols-[90px_1fr] items-center gap-2">
      <span className="text-xs font-medium text-muted-foreground">{label}:</span>
      <Select value={value} onValueChange={onChange}>
        <SelectTrigger className="h-9"><SelectValue /></SelectTrigger>
        <SelectContent>{options.map(o => <SelectItem key={o} value={o}>{o}</SelectItem>)}</SelectContent>
      </Select>
    </label>
  );
}

function PredictionBtn({ active, onClick, color, icon, title, desc }:
  { active: boolean; onClick: () => void; color: string; icon: React.ReactNode; title: string; desc: string }) {
  return (
    <button onClick={onClick}
      className={`w-full text-left rounded-xl overflow-hidden border-l-4 transition shadow-sm ${active ? "ring-2 ring-offset-2" : "opacity-90 hover:opacity-100"}`}
      style={{ borderLeftColor: color, boxShadow: active ? `0 8px 24px -10px ${color}` : undefined }}>
      <div className="px-3 py-2 flex items-center justify-center gap-2 text-white font-display font-semibold text-sm" style={{ background: color }}>
        {icon}{title}
      </div>
      <div className="px-3 py-2.5 text-xs text-muted-foreground bg-card">{desc}</div>
    </button>
  );
}

/* ===== Graph 1: Quality Prediction ===== */
function QualityPredictionPanel({ data, treatment, scenario, day }: { data: DashboardData; treatment: string; scenario: string; day: number }) {
  const { rows, predicted, Q0, k } = useMemo(() => predictQuality(data, treatment, scenario, day), [data, treatment, scenario, day]);
  const futureXs = Array.from({ length: Math.max(1, day - rows[rows.length - 1].Day + 1) }, (_, i) => rows[rows.length - 1].Day + i);
  const futureYs = futureXs.map(x => Math.max(0, Math.min(100, Q0 * Math.exp(-k * x))));
  const risk = qualityStatus(predicted);

  return (
    <div className="space-y-4">
      <Card className="card-soft p-5 border-0 border-l-4" style={{ borderLeftColor: "var(--leaf)" }}>
        <h3 className="font-display font-semibold text-xl">Graph 1: Predicted Quality Score</h3>
        <div className="mt-2 text-sm grid sm:grid-cols-2 gap-x-6 gap-y-1">
          <div><b>Treatment:</b> {treatment}</div>
          <div><b>Scenario:</b> {scenario}</div>
          <div><b>Prediction day:</b> {day}</div>
          <div><b>Predicted Quality:</b> {predicted.toFixed(2)}</div>
          <div className="sm:col-span-2"><b>Risk Level:</b> <span style={{ color: risk.color }}>{risk.label}</span></div>
        </div>
      </Card>

      <Card className="card-soft p-4 border-0">
        <Plot data={[
          { x: rows.map(r => r.Day), y: rows.map(r => r.Quality_Score), name: "Observed Quality", mode: "lines+markers", type: "scatter", line: { width: 3, color: "#0ea5e9" }, marker: { size: 10 } },
          { x: futureXs, y: futureYs, name: "Predicted Quality", mode: "lines+markers", type: "scatter", line: { width: 3, color: "#f97316", dash: "dash" }, marker: { size: 10, symbol: "diamond" } },
        ]} layout={{
          title: `Future Quality Score Prediction — ${treatment}`,
          xaxis: { title: { text: "Storage Day" } },
          yaxis: { title: { text: "Quality Score" }, range: [0, 105] },
          shapes: [{ type: "line", x0: rows[rows.length - 1].Day, x1: rows[rows.length - 1].Day, y0: 0, y1: 105, line: { color: "#94a3b8", dash: "dash" } }],
        }} style={{ height: 360 }} />
      </Card>

      <AIInsight mode="quality" treatment={treatment} scenario={scenario} day={day} predictedQuality={predicted} />
    </div>
  );
}

/* ===== Graph 2: Fruit Safety Index ===== */
function FruitSafetyPanel({ data, treatment, scenario, day }: { data: DashboardData; treatment: string; scenario: string; day: number }) {
  const { components, index } = useMemo(() => safetyComponents(data, treatment, scenario, day), [data, treatment, scenario, day]);
  const rec = eatingRec(index);

  return (
    <div className="space-y-4">
      <Card className="card-soft p-5 border-0 border-l-4" style={{ borderLeftColor: "#dc2626" }}>
        <h3 className="font-display font-semibold text-xl">Graph 2: Fruit Safety Index</h3>
        <p className="mt-2 text-sm text-muted-foreground">
          This graph evaluates whether the fruit/lettuce is recommended for eating. The index combines predicted Quality Score, morphology, yeasts, total bacteria, and lactic bacteria.
        </p>
        <p className="mt-2 text-sm"><b>Important biological interpretation:</b> Lactic bacteria are not automatically treated as harmful. They may represent beneficial biological activity that helps preserve the fruit.</p>
      </Card>

      <div className="grid sm:grid-cols-2 gap-4">
        <Card className="card-soft p-4 border-0 border-l-4" style={{ borderLeftColor: "var(--leaf)" }}>
          <div className="text-sm font-medium">Fruit Safety Index</div>
          <div className="mt-1 font-display font-semibold text-3xl">{index.toFixed(2)}</div>
        </Card>
        <Card className="card-soft p-4 border-0 border-l-4" style={{ borderLeftColor: rec.color }}>
          <div className="text-sm font-medium">Eating Recommendation</div>
          <div className="mt-1 font-display font-semibold text-lg" style={{ color: rec.color }}>{rec.label}</div>
        </Card>
      </div>

      <Card className="card-soft p-4 border-0 border-l-4" style={{ borderLeftColor: "#0ea5e9" }}>
        <div className="text-sm font-medium">Prediction Day</div>
        <div className="mt-1 font-display font-semibold text-xl">Day {day}</div>
      </Card>

      <Card className="card-soft p-4 border-0">
        <Plot data={[{
          x: components.map(c => c.name), y: components.map(c => c.value),
          type: "bar", marker: { color: components.map(c => c.color) },
        }]} layout={{
          title: `Fruit Safety Components — ${treatment}`,
          yaxis: { title: { text: "Component Score" }, range: [0, 105] },
          xaxis: { tickangle: -20 },
        }} style={{ height: 360 }} />
      </Card>

      <AIInsight mode="safety" treatment={treatment} scenario={scenario} day={day} safetyIndex={index} />
    </div>
  );
}

/* ===== Graph 3: Smart Recommendation ===== */
function SmartRecommendationPanel({ data, scenario, day }: { data: DashboardData; scenario: string; day: number }) {
  const scored = useMemo(() => data.treatments.map(t => {
    const { index, predicted } = safetyComponents(data, t, scenario, day);
    return { treatment: t, index, predicted };
  }).sort((a, b) => b.index - a.index), [data, scenario, day]);
  const best = scored[0];
  const rec = eatingRec(best.index);

  return (
    <div className="space-y-4">
      <Card className="card-soft p-5 border-0 border-l-4" style={{ borderLeftColor: "#7c3aed" }}>
        <h3 className="font-display font-semibold text-xl">Graph 3: Smart Recommendation</h3>
        <div className="mt-2 text-sm grid sm:grid-cols-2 gap-x-6 gap-y-1">
          <div><b>Best predicted treatment:</b> {best.treatment}</div>
          <div><b>Predicted Quality Score:</b> {best.predicted.toFixed(2)}</div>
          <div><b>Fruit Safety Index:</b> {best.index.toFixed(2)}</div>
          <div><b>Eating Recommendation:</b> <span style={{ color: rec.color }}>{rec.label}</span></div>
        </div>
        <p className="mt-3 text-sm text-muted-foreground">
          This recommendation is based on both predicted Quality Score and Fruit Safety Index. Lactic bacteria are interpreted as possible protective microbes, not automatically as risk.
        </p>
      </Card>

      <Card className="card-soft p-4 border-0">
        <Plot data={[{
          x: scored.map(s => s.treatment), y: scored.map(s => s.index),
          type: "bar",
          marker: { color: scored.map(s => s.treatment === best.treatment ? "#16a34a" : "#94a3b8") },
          text: scored.map(s => s.index.toFixed(1)), textposition: "outside",
        }]} layout={{
          title: `Fruit Safety Index by Treatment — Day ${day}`,
          yaxis: { title: { text: "Fruit Safety Index" }, range: [0, 110] },
          xaxis: { tickangle: -20 },
        }} style={{ height: 380 }} />
      </Card>

      <AIInsight mode="recommendation" treatment={best.treatment} scenario={scenario} day={day}
        predictedQuality={best.predicted} safetyIndex={best.index}
        bestTreatment={best.treatment} bestIndex={best.index} />
    </div>
  );
}

/* ===== AI insight block ===== */
function AIInsight(props: {
  mode: F3Mode; treatment: string; scenario: string; day: number;
  predictedQuality?: number; safetyIndex?: number;
  bestTreatment?: string; bestIndex?: number;
}) {
  const call = useServerFn(getFeature3Insight);
  const [text, setText] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // refetch when key inputs change
  const key = `${props.mode}|${props.treatment}|${props.scenario}|${props.day}`;
  useEffect(() => { setText(null); setError(null); }, [key]);

  async function run() {
    setLoading(true); setError(null);
    try {
      const res = await call({ data: {
        mode: props.mode, treatment: props.treatment, scenario: props.scenario, day: props.day,
        predictedQuality: props.predictedQuality ?? null,
        safetyIndex: props.safetyIndex ?? null,
        bestTreatment: props.bestTreatment ?? null,
        bestIndex: props.bestIndex ?? null,
      }});
      setText(res.text);
    } catch (e: any) {
      const msg = String(e?.message ?? e);
      if (msg.includes("429")) setError("AI rate limit reached. Please try again shortly.");
      else if (msg.includes("402")) setError("AI credits exhausted. Add credits in Settings → Plans & credits.");
      else setError("AI insight unavailable right now.");
    } finally { setLoading(false); }
  }

  return (
    <Card className="card-soft p-5 border-0 border-l-4" style={{ borderLeftColor: "#f59e0b" }}>
      <div className="flex items-start justify-between gap-3 mb-2">
        <div className="flex items-center gap-2">
          <Sparkles className="size-4 text-amber-500" />
          <h4 className="font-display font-semibold">AI Insight</h4>
        </div>
        <Button size="sm" variant="outline" onClick={run} disabled={loading} className="gap-1.5">
          {loading ? <Loader2 className="size-3.5 animate-spin" /> : <Sparkles className="size-3.5" />}
          {text ? "Regenerate" : "Generate"}
        </Button>
      </div>
      {!text && !error && !loading && (
        <p className="text-sm text-muted-foreground">Click <b>Generate</b> for an AI-written interpretation and recommendation based on the current prediction.</p>
      )}
      {loading && <p className="text-sm text-muted-foreground">Thinking…</p>}
      {error && <p className="text-sm text-red-600">{error}</p>}
      {text && <p className="text-sm leading-relaxed whitespace-pre-wrap">{text}</p>}
    </Card>
  );
}

/* ============================================================ shared */
function SectionHero({ title, subtitle, desc }: { title: string; subtitle: string; desc: string }) {
  return (
    <div className="card-soft p-6 md:p-8 border-0 relative overflow-hidden">
      <div className="absolute inset-0 hero-grad opacity-95" />
      <div className="relative text-white">
        <div className="text-xs uppercase tracking-widest opacity-80">{title}</div>
        <h2 className="mt-1 text-2xl md:text-3xl font-display font-semibold">{subtitle}</h2>
        <p className="mt-2 text-white/85 max-w-2xl">{desc}</p>
      </div>
    </div>
  );
}

// suppress unused
void TREATMENT_COLORS;
