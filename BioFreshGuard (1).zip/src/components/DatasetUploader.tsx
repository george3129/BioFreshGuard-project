import { useEffect, useRef, useState } from "react";
import { Upload, FileSpreadsheet, CheckCircle2, AlertCircle, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { importExcelToDashboard } from "@/lib/excel-import";
import type { DashboardData } from "@/lib/biofresh-data";

const DEFAULT_FILE_URL = "/BFG_DATABASE.xlsx";
const DEFAULT_FILE_NAME = "BFG_DATABASE.xlsx";

export function DatasetUploader({ data, onLoaded }: { data: DashboardData; onLoaded: (d: DashboardData) => void }) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [status, setStatus] = useState<"idle" | "loading" | "ok" | "error">("idle");
  const [message, setMessage] = useState<string>("");
  const [fileName, setFileName] = useState<string>("");
  const autoLoaded = useRef(false);

  async function handleFile(file: File) {
    setStatus("loading"); setFileName(file.name); setMessage("מנתח את הקובץ…");
    try {
      const next = await importExcelToDashboard(file, data);
      onLoaded(next);
      setStatus("ok");
      setMessage(`נטענו ${next.main_df.length} שורות · ${next.treatments.length} טיפולים · ${next.days.length} ימי אחסון.`);
    } catch (e: any) {
      setStatus("error");
      setMessage(e?.message ?? "שגיאה בקריאת הקובץ.");
    }
  }

  useEffect(() => {
    if (autoLoaded.current) return;
    autoLoaded.current = true;
    (async () => {
      try {
        const res = await fetch(DEFAULT_FILE_URL);
        if (!res.ok) return;
        const blob = await res.blob();
        const file = new File([blob], DEFAULT_FILE_NAME, { type: blob.type });
        await handleFile(file);
      } catch { /* ignore — user can still upload */ }
    })();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function reset() {
    setStatus("idle"); setFileName(""); setMessage("");
    if (inputRef.current) inputRef.current.value = "";
  }

  return (
    <section className="card-soft p-3 border-0">
      <div className="flex items-start gap-2.5">
        <div className="size-8 rounded-lg grid place-items-center hero-grad text-white shrink-0">
          <FileSpreadsheet className="size-4" />
        </div>
        <div className="flex-1 min-w-0">
          <h3 className="font-display font-semibold text-sm">Load Experimental Dataset</h3>

          <div className="mt-1.5 flex flex-wrap items-center gap-2">
            <input
              ref={inputRef}
              type="file"
              accept=".xlsx,.xls,application/vnd.ms-excel,application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
              className="hidden"
              onChange={(e) => { const f = e.target.files?.[0]; if (f) handleFile(f); }}
            />
            <Button onClick={() => inputRef.current?.click()} size="sm" variant="outline" className="gap-2 bg-white text-black hover:bg-white/90" disabled={status === "loading"}>
              <Upload className="size-3.5" />
              {status === "loading" ? "טוען…" : fileName ? "החלף קובץ" : "בחר קובץ Excel"}
            </Button>
            {fileName && (
              <div className="inline-flex items-center gap-1.5 text-xs bg-muted px-2 py-1 rounded-md">
                <FileSpreadsheet className="size-3.5 text-muted-foreground" />
                <span className="font-mono">{fileName}</span>
                <button onClick={reset} className="text-muted-foreground hover:text-foreground"><X className="size-3" /></button>
              </div>
            )}
          </div>

          {message && (
            <div className={`mt-2 inline-flex items-start gap-2 text-xs rounded-md px-2.5 py-1.5 ${
              status === "ok" ? "bg-emerald-50 text-emerald-800" :
              status === "error" ? "bg-red-50 text-red-800" :
              "bg-muted text-foreground"
            }`}>
              {status === "ok" && <CheckCircle2 className="size-3.5 mt-0.5" />}
              {status === "error" && <AlertCircle className="size-3.5 mt-0.5" />}
              <span>{message}</span>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
