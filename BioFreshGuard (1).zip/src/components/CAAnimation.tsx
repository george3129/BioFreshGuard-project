import { useEffect, useRef } from "react";

interface Props {
  history: number[][][];     // [frame][row][col] of 0/1
  fps?: number;
  className?: string;
}

/** Cellular Automata spoilage spread — refined visual. */
export function CAAnimation({ history, fps = 3, className }: Props) {
  const ref = useRef<HTMLCanvasElement>(null);
  const frameRef = useRef(0);

  useEffect(() => {
    const canvas = ref.current;
    if (!canvas || history.length === 0) return;
    const ctx = canvas.getContext("2d")!;
    const size = history[0].length;
    let raf = 0; let last = 0;
    frameRef.current = 0;

    const draw = (t: number) => {
      if (t - last > 1000 / fps) {
        const grid = history[frameRef.current % history.length];
        const w = canvas.width, h = canvas.height;
        const cw = w / size, ch = h / size;
        const r = Math.max(1, Math.min(cw, ch) * 0.18);

        // soft background gradient
        const bg = ctx.createLinearGradient(0, 0, 0, h);
        bg.addColorStop(0, "#f0fdf4");
        bg.addColorStop(1, "#dcfce7");
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, w, h);

        // cells, rounded, no harsh grid lines
        for (let row = 0; row < size; row++) {
          for (let col = 0; col < size; col++) {
            const v = grid[row][col];
            const x = col * cw + 1.5;
            const y = row * ch + 1.5;
            const cwi = cw - 3;
            const chi = ch - 3;
            ctx.fillStyle = v === 1 ? "#92400e" : "#15803d";
            ctx.globalAlpha = v === 1 ? 0.95 : 0.78;
            roundRect(ctx, x, y, cwi, chi, r);
            ctx.fill();
          }
        }
        ctx.globalAlpha = 1;

        // step pill — top right, rounded
        const label = `Step ${frameRef.current + 1} / ${history.length}`;
        ctx.font = "600 12px Inter, system-ui, sans-serif";
        const pad = 10;
        const tw = ctx.measureText(label).width + pad * 2;
        const th = 24;
        const px = w - tw - 10;
        const py = 10;
        ctx.fillStyle = "rgba(15,23,42,0.78)";
        roundRect(ctx, px, py, tw, th, 12);
        ctx.fill();
        ctx.fillStyle = "#ecfccb";
        ctx.textBaseline = "middle";
        ctx.fillText(label, px + pad, py + th / 2 + 0.5);

        frameRef.current++;
        last = t;
      }
      raf = requestAnimationFrame(draw);
    };
    raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [history, fps]);

  return (
    <div className="mx-auto" style={{ maxWidth: 240 }}>
      <canvas
        ref={ref}
        width={480}
        height={480}
        className={className}
        style={{
          width: "100%",
          display: "block",
          borderRadius: 16,
          background: "#f0fdf4",
          boxShadow: "inset 0 0 0 1px rgba(22,101,52,0.15), 0 6px 20px -10px rgba(22,101,52,0.35)",
        }}
      />
    </div>
  );
}

function roundRect(ctx: CanvasRenderingContext2D, x: number, y: number, w: number, h: number, r: number) {
  const rr = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + rr, y);
  ctx.arcTo(x + w, y, x + w, y + h, rr);
  ctx.arcTo(x + w, y + h, x, y + h, rr);
  ctx.arcTo(x, y + h, x, y, rr);
  ctx.arcTo(x, y, x + w, y, rr);
  ctx.closePath();
}
