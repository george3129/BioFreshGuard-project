import { useEffect, useRef, useState } from "react";

interface Props {
  data: any[];
  layout?: any;
  config?: any;
  className?: string;
  style?: React.CSSProperties;
}

const baseLayout: any = {
  font: { family: "Inter, system-ui, sans-serif", size: 12, color: "#cbd5e1" },
  paper_bgcolor: "rgba(0,0,0,0)",
  plot_bgcolor: "rgba(0,0,0,0)",
  margin: { l: 56, r: 24, t: 56, b: 48 },
  hoverlabel: { bgcolor: "#0f172a", bordercolor: "#334155", font: { color: "#e2e8f0" } },
  colorway: ["#34d399", "#86efac", "#a3e635", "#f59e0b", "#fb7185", "#a78bfa"],
};

export function Plot({ data, layout, config, className, style }: Props) {
  const ref = useRef<HTMLDivElement>(null);
  const [Plotly, setPlotly] = useState<any>(null);

  useEffect(() => {
    let cancelled = false;
    import("plotly.js-dist-min").then((m) => { if (!cancelled) setPlotly(m.default ?? m); });
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    if (!ref.current || !Plotly) return;
    const merged: any = {
      ...baseLayout,
      ...layout,
      title: typeof layout?.title === "string"
        ? { text: layout.title, font: { family: "Space Grotesk, sans-serif", size: 16, color: "#f1f5f9" }, x: 0.5 }
        : layout?.title ?? undefined,
      xaxis: { gridcolor: "#1e293b", zerolinecolor: "#334155", linecolor: "#334155", tickcolor: "#334155", ...(layout?.xaxis as object) },
      yaxis: { gridcolor: "#1e293b", zerolinecolor: "#334155", linecolor: "#334155", tickcolor: "#334155", ...(layout?.yaxis as object) },
      legend: { bgcolor: "rgba(15,23,42,0.75)", bordercolor: "#334155", borderwidth: 1, font: { color: "#e2e8f0" }, ...(layout?.legend as object) },
    };
    Plotly.newPlot(ref.current, data, merged, { displaylogo: false, responsive: true, ...config });
    const el = ref.current;
    return () => { Plotly.purge(el); };
  }, [Plotly, data, layout, config]);

  return <div ref={ref} className={className} style={{ width: "100%", height: 380, ...style }} />;
}
