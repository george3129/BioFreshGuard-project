"""
BioFreshGuard precompute pipeline.
Mirrors the Colab notebook logic 1:1, but generates synthetic data
that matches the experimental schema (since no Excel was provided),
then dumps everything the React dashboard needs into public/data.json.
"""
import json, os, math, random
import numpy as np
import pandas as pd
from functools import reduce
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.decomposition import PCA
from sklearn.linear_model import LinearRegression
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import r2_score, mean_absolute_error
import statsmodels.api as sm
from statsmodels.formula.api import ols

np.random.seed(42); random.seed(42)

# ---------------------------------------------------------------
# 1. REAL experimental data from BioFreshGuard Excel database
#    Transcribed verbatim from Colab notebook outputs (8 sheets:
#    morphology, bacteria, weight, color, Texture analyzer, TSS,
#    O2, CO2 -> merged on Day + Treatment).
# ---------------------------------------------------------------
TREATMENTS = ["CMC-3-methyl", "CMC-3-methyl+A", "CMC-3-methyl+B", "CMC-3-methyl+C", "control"]
DAYS = [0, 4, 7, 14]

COLS = ["Day","Treatment","morphology","bacteria_total","yeasts","lactic_bacteria",
        "weight_loss","color_delta_E","texture_force","TSS","O2","CO2"]
RAW = [
    (0,  "CMC-3-methyl",    5.00000,    6555.56, 0,       0.00,  0.00000,  5.51961, 8.26296, 4.33333, 21.00000, 0.00000),
    (4,  "CMC-3-methyl",    5.00000,  235000.00, 0,   28000.00,  1.40953, 11.44309, 8.35616, 4.46667, 20.53906, 0.30782),
    (7,  "CMC-3-methyl",    3.33333,  406333.33, 0,   49000.00,  2.33756, 15.88570, 7.43633, 4.25000, 14.50350, 0.44798),
    (14, "CMC-3-methyl",    3.00000,  806111.11, 0,   98000.00,  4.50297, 26.25178, 5.29007, 3.74444,  0.42052, 0.77501),
    (0,  "CMC-3-methyl+A",  5.00000,   34222.22, 0, 2422222.22,  0.00000,  5.35484, 7.71785, 4.66667, 21.00000, 0.00000),
    (4,  "CMC-3-methyl+A",  5.00000, 2666666.67, 0,  344444.44, 13.99081,  9.74413, 7.47227, 5.46667, 20.56355, 0.29880),
    (7,  "CMC-3-methyl+A",  3.00000, 4641000.00, 0,       0.00,  3.68337, 13.03609, 6.66650, 6.03333, 15.27892, 0.59220),
    (14, "CMC-3-methyl+A",  3.33333, 9247777.78, 0,       0.00,  0.00000, 20.71734, 4.78636, 7.35556,  2.94814, 1.27681),
    (0,  "CMC-3-methyl+B",  5.00000,    6944.44, 0, 6155555.56,  0.00000,  3.59730, 8.45524, 6.10000, 21.00000, 0.00000),
    (4,  "CMC-3-methyl+B",  5.00000,  221111.11, 0, 4122222.22, 13.71022, 11.58593, 8.52326, 6.50000, 20.63471, 0.12545),
    (7,  "CMC-3-methyl+B",  3.66667,  381736.11, 0, 2597222.22, 13.45000, 17.57740, 7.42250, 6.43333, 15.49575, 0.98093),
    (14, "CMC-3-methyl+B",  3.00000,  756527.78, 0,       0.00, 12.84281, 31.55749, 4.85407, 6.27778,  3.50486, 2.97703),
    (0,  "CMC-3-methyl+C",  5.00000,    7500.00, 0, 5666666.67,  0.00000,  6.03397, 9.43559, 8.03333, 21.00000, 0.00000),
    (4,  "CMC-3-methyl+C",  5.00000,  181916.67, 0, 4833333.33,  9.56827, 11.78060, 9.02520, 7.10000, 20.33188, 0.32476),
    (7,  "CMC-3-methyl+C",  3.33333,  312729.17, 0, 4208333.33,  1.60183, 16.09057, 9.24467, 7.65000, 16.04195, 0.57860),
    (14, "CMC-3-methyl+C" , 3.66667, 617958.33, 0, 2750000.00, 0.00000, 26.14717, 9.75676, 8.93333, 6.03211, 1.17089),
    (0,  "control",         5.00000,    6000.00, 0,       0.00,  0.00000, 13.37298, 7.68646, 5.46667, 21.00000, 0.00000),
    (4,  "control",         5.00000,   13888.89, 0,  220000.00,  8.22384, 14.16500, 5.43866, 6.10000, 20.61234, 0.34225),
    (7,  "control",         4.00000,   19805.56, 0,  385000.00,  8.98992, 14.75902, 5.66350, 5.60000, 13.62778, 1.11594),
    (14, "control",         2.66667,   33611.11, 0,  770000.00, 10.77742, 16.14505, 6.18812, 4.43333,  0.00000, 2.92122),
]
main_df = pd.DataFrame(RAW, columns=COLS).sort_values(["Treatment","Day"]).reset_index(drop=True)

# ---------------------------------------------------------------
# 2. Quality Score (from notebook)
# ---------------------------------------------------------------
analysis_df = main_df.copy()
analysis_df["log_bacteria_total"] = np.log1p(analysis_df["bacteria_total"])
analysis_df["log_yeasts"] = np.log1p(analysis_df["yeasts"])
analysis_df["log_lactic_bacteria"] = np.log1p(analysis_df["lactic_bacteria"])

positive_features = ["morphology", "texture_force", "O2", "log_lactic_bacteria"]
negative_features = ["CO2", "weight_loss", "color_delta_E", "log_bacteria_total", "log_yeasts"]

scaler = MinMaxScaler()
np_pos = pd.DataFrame(scaler.fit_transform(analysis_df[positive_features]), columns=positive_features)
np_neg = pd.DataFrame(scaler.fit_transform(analysis_df[negative_features]), columns=negative_features)
pos_score = np_pos.mean(axis=1)
neg_score = np_neg.mean(axis=1)
analysis_df["Quality_Score"] = (100 * (0.65 * pos_score + 0.35 * (1 - neg_score))).clip(0, 100)

# ---------------------------------------------------------------
# 3. Treatment summary
# ---------------------------------------------------------------
treatment_summary = analysis_df.groupby("Treatment").agg(
    Mean_Quality=("Quality_Score", "mean"),
    Day_14_Quality=("Quality_Score", lambda x: x.iloc[-1]),
    Mean_Morphology=("morphology", "mean"),
    Mean_CO2=("CO2", "mean"),
    Mean_O2=("O2", "mean"),
    Mean_Bacteria=("bacteria_total", "mean")
).reset_index().sort_values("Mean_Quality", ascending=False)
best_treatment = treatment_summary.iloc[0]["Treatment"]

# ---------------------------------------------------------------
# 4. PCA
# ---------------------------------------------------------------
pca_features = ["Day", "morphology", "CO2", "O2", "TSS", "texture_force", "weight_loss",
                "color_delta_E", "log_bacteria_total", "log_yeasts", "log_lactic_bacteria", "Quality_Score"]
X_pca = analysis_df[pca_features].fillna(analysis_df[pca_features].mean())
X_scaled = StandardScaler().fit_transform(X_pca)
pca = PCA(n_components=2)
pcs = pca.fit_transform(X_scaled)
analysis_df["PC1"] = pcs[:, 0]; analysis_df["PC2"] = pcs[:, 1]
loadings = pd.DataFrame(pca.components_.T, columns=["PC1", "PC2"], index=pca_features)
explained = pca.explained_variance_ratio_.tolist()

# ---------------------------------------------------------------
# 5. Correlation matrix
# ---------------------------------------------------------------
corr_features = pca_features + ["PC1", "PC2"]
corr_matrix = analysis_df[corr_features].corr().round(3)

# ---------------------------------------------------------------
# 6. ANOVA
# ---------------------------------------------------------------
anova_q = sm.stats.anova_lm(ols("Quality_Score ~ C(Treatment)", data=analysis_df).fit(), typ=2)
anova_m = sm.stats.anova_lm(ols("morphology ~ C(Treatment)", data=analysis_df).fit(), typ=2)

# ---------------------------------------------------------------
# 7. Linear regression (morphology target)
# ---------------------------------------------------------------
reg_df = pd.get_dummies(analysis_df.copy(), columns=["Treatment"], drop_first=True)
feat_cands = ["Day", "CO2", "O2", "TSS", "texture_force", "weight_loss", "color_delta_E",
              "log_bacteria_total", "log_yeasts", "log_lactic_bacteria", "PC1", "PC2"]
treat_cols = [c for c in reg_df.columns if c.startswith("Treatment_")]
feat_cols = feat_cands + treat_cols
X = reg_df[feat_cols].fillna(0); y = reg_df["morphology"]
lr = LinearRegression().fit(X, y); ypred = lr.predict(X)
lr_r2 = r2_score(y, ypred); lr_mae = mean_absolute_error(y, ypred)
lr_coefs = sorted([{"feature": f, "coef": float(c)} for f, c in zip(feat_cols, lr.coef_)],
                  key=lambda r: -r["coef"])
lr_actual_pred = [{"actual": float(a), "predicted": float(p)} for a, p in zip(y, ypred)]

# ---------------------------------------------------------------
# 8. Random Forest (quality target)
# ---------------------------------------------------------------
rf_df = pd.get_dummies(analysis_df.copy(), columns=["Treatment"], drop_first=True)
rf_feat = ["Day", "morphology", "CO2", "O2", "TSS", "texture_force", "weight_loss",
           "color_delta_E", "log_bacteria_total", "log_yeasts", "log_lactic_bacteria", "PC1", "PC2"] + \
          [c for c in rf_df.columns if c.startswith("Treatment_")]
Xr = rf_df[rf_feat].fillna(0); yr = rf_df["Quality_Score"]
rf = RandomForestRegressor(n_estimators=200, random_state=42).fit(Xr, yr)
yr_pred = rf.predict(Xr)
rf_r2 = r2_score(yr, yr_pred); rf_mae = mean_absolute_error(yr, yr_pred)
rf_importance = sorted([{"feature": f, "importance": float(i)} for f, i in zip(rf_feat, rf.feature_importances_)],
                       key=lambda r: -r["importance"])

# ---------------------------------------------------------------
# 9. Cellular Automata simulation
# ---------------------------------------------------------------
def create_initial_grid(size, p): return (np.random.rand(size, size) < p).astype(int)
def count_n(g, r, c):
    s = g.shape[0]; cnt = 0
    for dr in (-1, 0, 1):
        for dc in (-1, 0, 1):
            if dr == 0 and dc == 0: continue
            nr, nc = r + dr, c + dc
            if 0 <= nr < s and 0 <= nc < s: cnt += g[nr, nc]
    return cnt

def run_ca(size, steps, p0, base_p, neigh_e, prot_e):
    g = create_initial_grid(size, p0); hist = [g.copy()]
    for _ in range(steps):
        ng = g.copy()
        for r in range(size):
            for c in range(size):
                if g[r, c] == 1: continue
                pr = base_p + neigh_e * count_n(g, r, c) - prot_e
                pr = max(0, min(1, pr))
                if np.random.rand() < pr: ng[r, c] = 1
        g = ng; hist.append(g.copy())
    return hist

scenarios = {
    "Baseline": dict(p0=0.08, base_p=0.04, neigh_e=0.07, prot_e=0.02),
    "Stress":   dict(p0=0.15, base_p=0.10, neigh_e=0.12, prot_e=0.00),
    "Recovery": dict(p0=0.06, base_p=0.03, neigh_e=0.05, prot_e=0.04),
}
np.random.seed(42)
sim_results = {}
for name, p in scenarios.items():
    hist = run_ca(12, 14, p["p0"], p["base_p"], p["neigh_e"], p["prot_e"])
    sim_results[name] = {
        "history": [g.tolist() for g in hist],
        "progression": [float(g.mean() * 100) for g in hist],
        "final_grid": hist[-1].tolist(),
        "initial_pct": float(hist[0].mean() * 100),
        "final_pct": float(hist[-1].mean() * 100),
    }

# ---------------------------------------------------------------
# 10. Output JSON
# ---------------------------------------------------------------
def df_records(df): return json.loads(df.to_json(orient="records"))

out = {
    "treatments": TREATMENTS,
    "days": DAYS,
    "main_df": df_records(analysis_df),
    "treatment_summary": df_records(treatment_summary),
    "best_treatment": best_treatment,
    "pca": {
        "features": pca_features,
        "explained_variance": explained,
        "loadings": [{"feature": f, "PC1": float(loadings.loc[f, "PC1"]),
                      "PC2": float(loadings.loc[f, "PC2"])} for f in pca_features],
        "points": [{"PC1": float(r.PC1), "PC2": float(r.PC2), "Day": int(r.Day),
                    "Treatment": r.Treatment, "Quality_Score": float(r.Quality_Score)}
                   for r in analysis_df.itertuples()],
    },
    "correlation": {
        "features": corr_features,
        "matrix": corr_matrix.values.tolist(),
    },
    "anova": {
        "quality": {"F": float(anova_q["F"].iloc[0]), "p": float(anova_q["PR(>F)"].iloc[0])},
        "morphology": {"F": float(anova_m["F"].iloc[0]), "p": float(anova_m["PR(>F)"].iloc[0])},
    },
    "linear_regression": {
        "r2": float(lr_r2), "mae": float(lr_mae),
        "coefficients": lr_coefs, "actual_vs_pred": lr_actual_pred,
    },
    "random_forest": {
        "r2": float(rf_r2), "mae": float(rf_mae),
        "feature_importance": rf_importance,
    },
    "scenarios": list(scenarios.keys()),
    "simulation_results": sim_results,
}

def sanitize(o):
    if isinstance(o, float):
        return None if (math.isnan(o) or math.isinf(o)) else o
    if isinstance(o, dict):
        return {k: sanitize(v) for k, v in o.items()}
    if isinstance(o, list):
        return [sanitize(v) for v in o]
    return o

os.makedirs("public", exist_ok=True)
with open("public/data.json", "w") as f:
    json.dump(sanitize(out), f, allow_nan=False)
print("Wrote public/data.json:", os.path.getsize("public/data.json"), "bytes")
print("Best treatment:", best_treatment)
print("PCA explained:", explained)
print("ANOVA quality p:", out["anova"]["quality"]["p"])
print("LR R2:", lr_r2, "RF R2:", rf_r2)
